package com.email.assistant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailAssistantApplicationTests {

	@Test
	void contextLoads() {
	}

}
