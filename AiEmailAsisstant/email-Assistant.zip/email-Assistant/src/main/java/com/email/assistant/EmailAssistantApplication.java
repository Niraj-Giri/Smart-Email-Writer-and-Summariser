package com.email.assistant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailAssistantApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailAssistantApplication.class, args);
	}

}
